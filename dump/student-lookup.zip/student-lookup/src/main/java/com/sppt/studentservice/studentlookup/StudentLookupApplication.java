package com.sppt.studentservice.studentlookup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentLookupApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentLookupApplication.class, args);
	}
}
